#include "DateComparator.h"

using namespace std;

DateComparator::DateComparator():
	year1(2000),  month1(1), day1(1),
	year2(2023), month2(12), day2(31),
	difference(0) {}

void DateComparator::readFile(const char *fileName) {
	//TODO:
	//Read the data from the txt file.
	// 
	//Hint: You can use get() to get a character in ifstream.
	//      You can use getline() to get one line in the txt file.
	//      You can use stoi() to change variable type from string to int
}
void DateComparator::setOrder()
{
	//TODO:
	//Compare the order of the two dates.
	//Set the earlier date as {year1, month1, day1} and the later one as {year2, month2, day2}.
}

void DateComparator::setDifference()
{
	//TODO:
	//Calculate the number of days between the two dates.
}

bool DateComparator::isLeapYear(int year_) 
{
	//TODO: 
	//Determine whether year_ is a leap year.
}

void DateComparator::print()
{
	//TODO: 
	//The function output the result on the screen.
	//Hint: You can use setw() to set the length of the number.
	//      You can use setfill('c') to fill 'c' to the empty space.
	//      Two functions of above is in iomanip header file. 
}