#include <iostream>
#include "DateComparator.h"
using namespace std;

int main() {
	DateComparator calculator;
	calculator.readFile("input.txt");
	//calculator.readFile("input2.txt");

	return 0;
}
