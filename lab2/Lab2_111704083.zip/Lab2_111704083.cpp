#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
using namespace std;
int GCD(int a, int b){
   if(b == 0) return a;
   return GCD(b,a % b);
}
class PrimeFactorization {
private:
	int num1, num2;
	vector<int> num1_factor, num2_factor;

public:
	PrimeFactorization() {}
	PrimeFactorization(int a, int b) {
	    this -> num1 = a; //�i�D�q���o��perameter num1�N��PF��J�����a
	    this -> num2 = b; //�i�D�q���o��perameter num2�N��PF��J�����b
	}
	void Get_Prime_Factorization() {
	    int tmp1 = num1,tmp2 = num2;
	    for(int i = 2;i <= sqrt(tmp1);i++){
             while(tmp1 % i == 0){
                num1_factor.push_back(i);
                tmp1 /= i;
             }
	    }
	    if(tmp1 > 1)  num1_factor.push_back(tmp1);
	    for(int i = 2;i <= sqrt(tmp2);i++){
             while(tmp2 % i == 0){
                num2_factor.push_back(i);
                tmp2 /= i;
             }
	    }
	    if(tmp2 > 1)  num2_factor.push_back(tmp2);
	}

	void Print_Prime_Factorization() {
	    cout << "num1_Prime_factor :\"";
		for(int i  = 0;i < num1_factor.size();i++) cout << num1_factor[i] << " ";
		cout << "\"" << endl;
        cout << "num2_Prime_factor :\"";
		for(int i  = 0;i < num2_factor.size();i++) cout << num2_factor[i] << " ";
		cout << "\"" << endl;
	}

	void Print_LCM() {
	    if(num1 > num2) cout << "LCM: " << (long long int) num1 * num2 / GCD(num1,num2) << endl;
	    else cout << "LCM: " << (long long int) num1 * num2 / GCD(num2,num1) << endl;
	}

};

int main() {
	int n;
	cin >> n;

	for (int i = 0; i < n; i++) {
		int a, b;
		cin >> a >> b;

		cout << "num1 = " << a << endl;
		cout << "num2 = " << b << endl;

		PrimeFactorization PF(a, b);

		PF.Get_Prime_Factorization();
		PF.Print_Prime_Factorization();
		PF.Print_LCM();

		cout << endl;

	}

	system("PAUSE");
	return 0;
}
