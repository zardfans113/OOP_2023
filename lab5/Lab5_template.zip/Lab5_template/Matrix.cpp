#include "Matrix.h"

//TODO: Implement the constructors.
Matrix::Matrix() {}
Matrix::Matrix(float a, float b, float c, float d) {}

void Matrix::readFile(const char* fileName) {
	ifstream inputFile;
	//TODO: Read the input file here.
}

void Matrix::reset() {
	//TODO: reset all the data member.
}

Matrix Matrix::operator +(Matrix b) {
	//TODO: perform + opearion overloading
}
Matrix Matrix::operator *(Matrix b) {
	//TODO: perform * opearion overloading
}

ifstream& operator >> (ifstream& in, Matrix& i) {
	//TODO: perform input overloading
}
ostream& operator << (ostream& out, const Matrix& i) {
	//TODO: perform output overloading
	//Hint: You can use 'setw()' to set the length of the number.
	//      You can use 'fixed' to make the floating point output displayed in decimal point representation.
	//      You can use 'setprecision()' to set the number of decimal places to be output.
	//      Three functions of above is in iomanip header file.
}
