#include <iostream>
#include <fstream>
#include "Matrix.h"

using namespace std;
int main()
{
	Matrix Matrix;
	Matrix.readFile("input1.txt");
	return 0;
}
