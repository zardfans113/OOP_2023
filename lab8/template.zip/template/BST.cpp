#include "BST.h"
#include<iostream>
#include<queue>
using namespace std;

void BST::insert(Node* insertNode) {
	//TODO: insert a node to BST
}

void BST::InOrder_traversal(Node* root)
{
	//TODO: Inorder traversal
}

void BST::PreOrder_traversal(Node* root)
{
	//TODO: Preorder traversal
}

void BST::PostOrder_traversal(Node* root)
{
	//TODO: Postorder traversal

}

Node* BST::getRoot() {
	//TODO: return root of BST

}